# pyfrspell

Python package for French lemma prediction and derivative form generation,
ported from FR-SPELL and bundled with ONNX INT8 model files.

## Install

```bash
pip3 install pyfrspell
```

## Quick Start

```python
from pyfrspell import FrSpell

predictor = FrSpell()

lemma = predictor.lemma("mangeons")
noun = predictor.noun_derive("chat", "THD_PLF")
adje = predictor.adje_derive("beau", "THD_F")
verb = predictor.verb_derive("manger", "FST_PL", "INDI", "PRES")

print(lemma)
print(noun)
print(adje)
print(verb)
```

## API

- `predictor.lemma(input_word)`
- `predictor.noun_derive(lemma, person)`
- `predictor.adje_derive(lemma, person)`
- `predictor.verb_derive(lemma, person, mode, tense)`
- `predictor.derive(lemma, word_type, person, mode, tense)`

Allowed `word_type` values:

- `NOUN`
- `ADJE`
- `VERB`

Allowed `person` values:

- `FST`
- `SND`
- `THD_M`
- `THD_F`
- `FST_PL`
- `SND_PL`
- `THD_PLM`
- `THD_PLF`

Allowed `mode` values:

- `INDI`
- `SUBJ`
- `COND`
- `PART`
- `IMPE`
- `INFI`

Allowed `tense` values in current implementation:

- `PRES`
- `IMPA`
- `FUTU`
- `PASS`

## Package Build (for PyPI upload)

```bash
python -m pip install --upgrade build
python -m build
```

Generated artifacts:

- `dist/pyfrspell-<version>-py3-none-any.whl`
- `dist/pyfrspell-<version>.tar.gz`

Then upload to PyPI:

```bash
python -m pip install --upgrade twine
python -m twine upload dist/*
```
